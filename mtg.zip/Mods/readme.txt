How to make mod:

1. Create Folder in Mods
2. Create DLL and follow WIKI
3. Add Info Attribute over mod

>Info

[Info("name", "desc", "your name", "version")]
class MyMod : IMod {}