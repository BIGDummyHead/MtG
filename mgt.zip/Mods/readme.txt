How to make mod:

1. Create Folder in Mods
2. Create DLL and follow WIKI
3. Create .mod file

> .mod File

{
    "name": "Mod Name",
    "desc": "Mod Desc",
    "dev": "Mod Dev",
    "ver": "1.0.0.0"
}